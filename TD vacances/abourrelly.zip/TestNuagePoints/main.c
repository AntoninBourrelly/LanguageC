/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.c
 * Author: jribeiro
 *
 * Created on 27 octobre 2018, 21:33
 */


#include <stdio.h>
#include <stdlib.h>
#define NB_RELEVE 5

/*
 * 
 */

int main(int argc, char** argv) {

    int indice;
    float valMoy;
    int valMin;
    int valMax;
    int indicePetit;
    int indiceGrand;
    int nuagePoints[NB_RELEVE];
    float somme;


    for (indice = 0; indice <= NB_RELEVE - 1; indice++) {
        printf("Entrez une valeur : ");
        scanf("%u", &nuagePoints[indice]);
    }

    for (indice = 0; indice <= NB_RELEVE - 1; indice++) {
        
        if (nuagePoints[indice] < valMin) {
            valMin = nuagePoints[indice];
            indicePetit = indice;
            
        } else if (nuagePoints[indice] > valMax) {
            
            valMax = nuagePoints[indice];
            indiceGrand = indice;
        }
    }
    nuagePoints[indicePetit] = 0;
    nuagePoints[indiceGrand] = 0;

    somme = nuagePoints[0] + nuagePoints[1] + nuagePoints[2] + nuagePoints[3] + nuagePoints[4];
    
    valMoy = somme / (NB_RELEVE - 2);
    
    printf("La moyenne est %.2f", valMoy);

    return (EXIT_SUCCESS);
}

